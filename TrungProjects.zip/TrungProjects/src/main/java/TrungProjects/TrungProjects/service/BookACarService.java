package TrungProjects.TrungProjects.service;

import TrungProjects.TrungProjects.entity.BookACar;

import java.util.List;

public interface BookACarService {
    List<BookACar> getAllBookACar();
    BookACar findBookACarById(Long bookACarId) throws Exception;
    void save(BookACar bookACar);
    void deleteBookACar(Long bookACarId);
}
