package TrungProjects.TrungProjects.service;


import TrungProjects.TrungProjects.entity.BookACar;
import TrungProjects.TrungProjects.repository.BookACarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookACarServiceImpl implements BookACarService{

    private BookACarRepository bookACarRepository;

    @Autowired
    public BookACarServiceImpl(BookACarRepository bookACarRepository){
        this.bookACarRepository = bookACarRepository;
    }

    public List<BookACar> getAllBookACar(){
        return bookACarRepository.findAll();
    }

    public BookACar findBookACarById(Long bookACarId) throws Exception {
        Optional<BookACar> optionalBookACar = bookACarRepository.findById(bookACarId);

        BookACar car = null;

        if (optionalBookACar.isPresent()){
            car = optionalBookACar.get();
        }else {
            throw new Exception("not found"+bookACarId);
        }
        return car;
    }

    public void save(BookACar bookACar){
        bookACarRepository.save(bookACar);
    }

    public void deleteBookACar(Long bookACarId){
        bookACarRepository.deleteById(bookACarId);
    }
}
