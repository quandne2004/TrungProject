package TrungProjects.TrungProjects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrungProjectsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrungProjectsApplication.class, args);
	}

}
