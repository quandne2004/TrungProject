package TrungProjects.TrungProjects.controller;


import TrungProjects.TrungProjects.entity.BookACar;
import TrungProjects.TrungProjects.service.BookACarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("bookACars")
public class BookACarController {


    private BookACarService bookACarService;

    public BookACarController(BookACarService bookACarService){
        this.bookACarService=bookACarService;
    }


    @GetMapping("/list")
    public String listBookACar(Model model) {
        model.addAttribute("bookACars", bookACarService.getAllBookACar());
        return "bookACar_list"; // Tên của template trong thư mục templates
    }

    @GetMapping("/showFormForAdd")
    public String showFormForAdd(Model model) {
        BookACar bookACar = new BookACar();
        model.addAttribute("bookACar", bookACar);
        return "bookACar_form"; // Tên của template trong thư mục templates
    }

    @GetMapping("/showFormForUpdate")
    public String showFormForUpdate(@RequestParam("bookACarId") Long id, Model model) throws Exception {
        BookACar bookACar = bookACarService.findBookACarById(id);
        model.addAttribute("bookACar", bookACar);
        return "bookACar_form"; // Tên của template trong thư mục templates
    }

    @PostMapping("/save")
    public String saveBookACar(@ModelAttribute("bookACar") BookACar bookACar) {
        bookACarService.save(bookACar);
        return "redirect:/bookACars/list";
    }

    @GetMapping("/delete")
    public String delete(@RequestParam("bookACarId") Long id) {
        bookACarService.deleteBookACar(id);
        return "redirect:/bookACars/list";
    }
}
